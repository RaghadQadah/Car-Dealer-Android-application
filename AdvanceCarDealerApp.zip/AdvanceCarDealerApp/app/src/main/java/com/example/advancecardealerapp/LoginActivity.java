package com.example.advancecardealerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Checkable;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    SharedPrefManager sharedPrefManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPrefManager =SharedPrefManager.getInstance(this);
        setContentView(R.layout.activity_login);
        final Button signUp = findViewById(R.id.signup);
        final Button signIn = findViewById(R.id.signin);
        final EditText email = (EditText)findViewById(R.id.email);
        final EditText password = (EditText)findViewById(R.id.pass);
        final CheckBox checkBox = findViewById(R.id.checkBox);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                LoginActivity.this.startActivity(intent);
                finish();
            }
        });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    Toast toast =Toast.makeText(LoginActivity.this, "Wrong Email or Password... Try Again",Toast.LENGTH_LONG);
                    toast.show();
                }
                else {
                    DataBaseHelper dataBaseHelper =new DataBaseHelper(LoginActivity.this,"User",null,1);
                    boolean isValid = dataBaseHelper.LogIn(email.getText().toString(),password.getText().toString());
                    if(isValid){
                        Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                        LoginActivity.this.startActivity(intent);
                        finish();

                        Toast toast =Toast.makeText(LoginActivity.this, "Login Successful",Toast.LENGTH_LONG);
                        toast.show();


                        if(checkBox.isSelected()){
                            sharedPrefManager.writeString("userName",email.getText().toString());
                            sharedPrefManager.writeString("password",password.getText().toString());
                            Toast.makeText(LoginActivity.this, "Data Saved", Toast.LENGTH_SHORT).show();


                        }



                    }
                    else{
                        Toast toast =Toast.makeText(LoginActivity.this, "Check Email or Password",Toast.LENGTH_LONG);
                        toast.show();
                    }
                }
            }
        });
    }
}