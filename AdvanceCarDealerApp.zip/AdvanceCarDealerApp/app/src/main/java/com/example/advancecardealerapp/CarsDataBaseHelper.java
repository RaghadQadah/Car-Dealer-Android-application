package com.example.advancecardealerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

public class CarsDataBaseHelper extends SQLiteOpenHelper{

    public CarsDataBaseHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS Car(" +
                "MODEL TEXT," +
                "MAKE TEXT," +
                "DISTANCE TEXT, " +
                "YEAR TEXT," +
                "PRICE TEXT," +
                "ACCIDENTS TEXT," +
                "PRIMARY KEY(MODEL,DISTANCE))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public Cursor getAllCars() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.rawQuery("SELECT * FROM Car", null);
    }


    public void deleteAllCars(){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        sqLiteDatabase.delete("Car",null,null);
    }



    public void insert(String MODEL,String MAKE,String DISTANCE,int YEAR,int PRICE, boolean ACCIDENTS) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("MODEL", MODEL);
        contentValues.put("MAKE",MAKE);
        contentValues.put("DISTANCE", DISTANCE);
        contentValues.put("YEAR", YEAR);
        contentValues.put("PRICE", PRICE);
        contentValues.put("ACCIDENTS", ACCIDENTS);
        sqLiteDatabase.insert("Car", null, contentValues);
    }
}