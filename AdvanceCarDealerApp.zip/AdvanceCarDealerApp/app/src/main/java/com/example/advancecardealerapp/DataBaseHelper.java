package com.example.advancecardealerapp;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    public DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //sqLiteDatabase.execSQL("DROP TABLE USER");
        sqLiteDatabase.execSQL("CREATE TABLE USER(" +
                "EMAIL TEXT PRIMARY KEY," +
                "FIRSTNAME TEXT,LASTNAME TEXT, " +
                "PASSWORD TEXT," +
                "GENDER TEXT," +
                "PHONE TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insert(String Email,String FirstName,String LastName,String Password,String Gender, String Phone) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("EMAIL", Email);
        contentValues.put("FIRSTNAME",FirstName);
        contentValues.put("LASTNAME", LastName);
        contentValues.put("PASSWORD", Password);
        contentValues.put("GENDER", Gender);
        contentValues.put("PHONE", Phone);
        sqLiteDatabase.insert("User", null, contentValues);
    }

    public boolean LogIn(String email,String password){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT EMAIL, PASSWORD FROM User WHERE EMAIL = ?",new String[] {email});
        if(cursor.getCount()>0) {
            if (cursor.moveToFirst()){
                String data = cursor.getString(cursor.getColumnIndex("PASSWORD"));
                if(password.equals(data))
                    return true;
            }
            return false;
        }
        else
            return false;
    }
}