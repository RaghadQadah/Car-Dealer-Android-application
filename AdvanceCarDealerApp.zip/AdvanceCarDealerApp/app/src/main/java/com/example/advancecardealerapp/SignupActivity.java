package com.example.advancecardealerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.regex.Pattern;

public class SignupActivity extends AppCompatActivity {
    SharedPrefManager sharedPrefManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        sharedPrefManager =SharedPrefManager.getInstance(this);
        String[] options = { "Male", "Female" };
        final Spinner genderSpinner =(Spinner) findViewById(R.id.gender_spinner);
        ArrayAdapter<String> objGenderArr = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, options);
        genderSpinner.setAdapter(objGenderArr);
        final EditText firstName = (EditText)findViewById(R.id.first_name);
        final EditText lastName = (EditText)findViewById(R.id.last_name);
        final EditText email = (EditText)findViewById(R.id.e_mail);
        final EditText password = (EditText)findViewById(R.id.password);
        final EditText confirm = (EditText)findViewById(R.id.confirm);
        final EditText phone = (EditText)findViewById(R.id.phone);
        final Button signUp = findViewById(R.id.signup_button);
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(email.getText().toString().isEmpty() || firstName.getText().toString().isEmpty() ||
                        lastName.getText().toString().isEmpty() || password.getText().toString().isEmpty() ||
                        confirm.getText().toString().isEmpty() || phone.getText().toString().isEmpty()){
                    Toast toast =Toast.makeText(SignupActivity.this, "Something's Missing... Check Input Fields",Toast.LENGTH_LONG);
                    toast.show();
                }
                else if(!email.getText().toString().matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
                    Toast toast =Toast.makeText(SignupActivity.this, "Email is not Valid",Toast.LENGTH_LONG);
                    toast.show();
                }
                else if(firstName.getText().toString().length() < 2 && lastName.getText().toString().length() < 2){
                    Toast toast =Toast.makeText(SignupActivity.this, "Name can't be less than 2 characters",Toast.LENGTH_LONG);
                    toast.show();
                }
                else if(!Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[-_,.@#$%^&+=])(?=\\S+$).{4,15}$").matcher(password.getText().toString()).matches()){
                    Toast toast =Toast.makeText(SignupActivity.this, "password should include capital,small,number,special char",Toast.LENGTH_LONG);
                    toast.show();
                }
                else if(!password.getText().toString().equals(confirm.getText().toString())){
                    Toast toast =Toast.makeText(SignupActivity.this, "passwords doesn't match",Toast.LENGTH_LONG);
                    toast.show();
                }
                else if(phone.getText().toString().length() < 10 && !phone.getText().toString().substring(0,2).equals("05")){
                    Toast toast =Toast.makeText(SignupActivity.this, "Phone not valid",Toast.LENGTH_LONG);
                    toast.show();
                }
                else{
                    DataBaseHelper dataBaseHelper =new DataBaseHelper(SignupActivity.this,"User",null,1);
                    dataBaseHelper.insert(email.getText().toString(),firstName.getText().toString(),lastName.getText().toString(),
                            password.getText().toString(),genderSpinner.getSelectedItem().toString(),phone.getText().toString());
                    Toast toast =Toast.makeText(SignupActivity.this, "Successfully Registered",Toast.LENGTH_LONG);
                    toast.show();
                    sharedPrefManager.writeString("userName",email.getText().toString());
                    sharedPrefManager.writeString("password",password.getText().toString());
                    Toast.makeText(SignupActivity.this, "Data Saved", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(SignupActivity.this, HomeActivity.class);
                    SignupActivity.this.startActivity(intent);
                    finish();
                }
            }
        });
    }
}